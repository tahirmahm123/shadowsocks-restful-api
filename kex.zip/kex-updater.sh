#!/bin/bash
source /etc/.ddt
ZIP_OUT="/usr/local/kex.zip"
DIR_OUT="/usr/local/kex"
rm -rf $DIR_OUT;
mkdir -p $DIR_OUT;
curl -L -o $ZIP_OUT "$PANEL_URL/misc/kex.zip"
unzip -o $ZIP_OUT -d $DIR_OUT
npm install --prefix /usr/local/kex/
systemctl restart kex.service
